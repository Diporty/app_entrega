"""
Modelos SQLAlchemy para a aplicação Intera.
"""
from sqlalchemy import Column, String, Text, Integer, Float, Boolean, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.database import Base


class UserType(str, enum.Enum):
    """Tipos de usuários no sistema."""
    CUSTOMER = "customer"
    MERCHANT = "merchant"
    DRIVER = "driver"
    ADMIN = "admin"


class OrderStatus(str, enum.Enum):
    """Status possíveis de um pedido."""
    PENDING = "pending"
    ACCEPTED = "accepted"
    PREPARING = "preparing"
    READY = "ready"
    ON_THE_WAY = "on_the_way"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


class User(Base):
    """Modelo de usuário."""
    __tablename__ = "users"

    id = Column(String(64), primary_key=True, index=True)
    name = Column(String(255))
    email = Column(String(320), unique=True, index=True)
    phone = Column(String(20))
    password_hash = Column(String(255))
    user_type = Column(Enum(UserType), default=UserType.CUSTOMER)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_signed_in = Column(DateTime, default=datetime.utcnow)

    # Relacionamentos
    merchant = relationship("Merchant", back_populates="user", uselist=False)
    driver = relationship("Driver", back_populates="user", uselist=False)
    orders = relationship("Order", back_populates="customer")


class Merchant(Base):
    """Modelo de comerciante."""
    __tablename__ = "merchants"

    id = Column(String(64), primary_key=True, index=True)
    user_id = Column(String(64), ForeignKey("users.id"), unique=True)
    business_name = Column(String(255), index=True)
    description = Column(Text)
    category = Column(String(100), index=True)  # restaurant, grocery, pharmacy, etc
    phone = Column(String(20))
    address = Column(Text)
    latitude = Column(Float)
    longitude = Column(Float)
    is_active = Column(Boolean, default=True)
    rating = Column(Float, default=5.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relacionamentos
    user = relationship("User", back_populates="merchant")
    products = relationship("Product", back_populates="merchant", cascade="all, delete-orphan")
    orders = relationship("Order", back_populates="merchant")


class Product(Base):
    """Modelo de produto."""
    __tablename__ = "products"

    id = Column(String(64), primary_key=True, index=True)
    merchant_id = Column(String(64), ForeignKey("merchants.id"))
    name = Column(String(255), index=True)
    description = Column(Text)
    price = Column(Float)
    category = Column(String(100))
    image_url = Column(Text)
    is_available = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relacionamentos
    merchant = relationship("Merchant", back_populates="products")
    order_items = relationship("OrderItem", back_populates="product")


class Order(Base):
    """Modelo de pedido."""
    __tablename__ = "orders"

    id = Column(String(64), primary_key=True, index=True)
    customer_id = Column(String(64), ForeignKey("users.id"))
    merchant_id = Column(String(64), ForeignKey("merchants.id"))
    driver_id = Column(String(64), ForeignKey("drivers.id"), nullable=True)
    status = Column(Enum(OrderStatus), default=OrderStatus.PENDING)
    total_amount = Column(Float)
    delivery_fee = Column(Float, default=0.0)
    delivery_address = Column(Text)
    delivery_latitude = Column(Float)
    delivery_longitude = Column(Float)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    delivered_at = Column(DateTime, nullable=True)

    # Relacionamentos
    customer = relationship("User", back_populates="orders")
    merchant = relationship("Merchant", back_populates="orders")
    driver = relationship("Driver", back_populates="orders")
    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")


class OrderItem(Base):
    """Modelo de item do pedido."""
    __tablename__ = "order_items"

    id = Column(String(64), primary_key=True, index=True)
    order_id = Column(String(64), ForeignKey("orders.id"))
    product_id = Column(String(64), ForeignKey("products.id"))
    quantity = Column(Integer)
    price = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relacionamentos
    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")


class Driver(Base):
    """Modelo de entregador."""
    __tablename__ = "drivers"

    id = Column(String(64), primary_key=True, index=True)
    user_id = Column(String(64), ForeignKey("users.id"), unique=True)
    full_name = Column(String(255))
    phone = Column(String(20))
    vehicle = Column(String(100))
    license_plate = Column(String(20))
    is_active = Column(Boolean, default=True)
    is_available = Column(Boolean, default=False)
    rating = Column(Float, default=5.0)
    total_deliveries = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relacionamentos
    user = relationship("User", back_populates="driver")
    orders = relationship("Order", back_populates="driver")

