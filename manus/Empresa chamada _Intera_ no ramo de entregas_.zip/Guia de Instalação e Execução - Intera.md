# Guia de Instalação e Execução - Intera

## Visão Geral

O projeto Intera é um aplicativo de entregas para cidades pequenas, desenvolvido em **Python** com:

- **Backend:** FastAPI (API RESTful)
- **Frontend:** Streamlit (Interface web interativa)
- **Banco de Dados:** SQLite (desenvolvimento) / PostgreSQL (produção)

## Estrutura do Projeto

```
intera_delivery_app/
├── backend/                    # API FastAPI
│   ├── app/
│   │   ├── main.py            # Aplicação principal
│   │   ├── models.py          # Modelos SQLAlchemy
│   │   ├── schemas.py         # Schemas Pydantic
│   │   ├── database.py        # Configuração do banco de dados
│   │   └── routers/           # Rotas da API
│   │       ├── auth.py        # Autenticação
│   │       ├── merchants.py   # Comerciantes
│   │       ├── products.py    # Produtos
│   │       ├── orders.py      # Pedidos
│   │       └── drivers.py     # Entregadores
│   └── requirements.txt
├── frontend/                   # Interface Streamlit
│   ├── app.py                 # Aplicação principal
│   ├── utils/
│   │   └── api_client.py      # Cliente para a API
│   ├── requirements.txt
│   └── .streamlit/
│       └── config.toml        # Configuração do Streamlit
└── planejamento_intera_app.md # Planejamento do projeto
```

## Instalação

### Pré-requisitos

- Python 3.8 ou superior
- pip (gerenciador de pacotes do Python)

### Passo 1: Clonar ou Preparar o Projeto

```bash
cd /home/ubuntu/intera_delivery_app
```

### Passo 2: Instalar Dependências do Backend

```bash
cd backend
pip install -r requirements.txt
```

### Passo 3: Instalar Dependências do Frontend

```bash
cd ../frontend
pip install -r requirements.txt
```

## Executando a Aplicação

### Terminal 1: Executar o Backend (FastAPI)

```bash
cd /home/ubuntu/intera_delivery_app/backend
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

A API estará disponível em: `http://localhost:8000`
Documentação interativa (Swagger): `http://localhost:8000/docs`

### Terminal 2: Executar o Frontend (Streamlit)

```bash
cd /home/ubuntu/intera_delivery_app/frontend
streamlit run app.py
```

O frontend estará disponível em: `http://localhost:8501`

## Funcionalidades Implementadas

### Backend (API FastAPI)

#### Autenticação (`/api/auth`)
- ✅ Registrar novo usuário
- ✅ Login com email e senha
- ✅ Obter informações do usuário atual

#### Comerciantes (`/api/merchants`)
- ✅ Criar novo comerciante
- ✅ Obter informações de um comerciante
- ✅ Listar comerciantes (com filtro por categoria)
- ✅ Atualizar informações de um comerciante
- ✅ Desativar um comerciante

#### Produtos (`/api/products`)
- ✅ Criar novo produto
- ✅ Obter informações de um produto
- ✅ Listar produtos de um comerciante
- ✅ Atualizar informações de um produto
- ✅ Deletar um produto

#### Pedidos (`/api/orders`)
- ✅ Criar novo pedido
- ✅ Obter informações de um pedido
- ✅ Listar pedidos de um cliente
- ✅ Listar pedidos de um comerciante
- ✅ Atualizar status de um pedido
- ✅ Atribuir entregador a um pedido

#### Entregadores (`/api/drivers`)
- ✅ Criar novo entregador
- ✅ Obter informações de um entregador
- ✅ Listar entregadores disponíveis
- ✅ Atualizar informações de um entregador
- ✅ Alternar disponibilidade de um entregador

### Frontend (Streamlit)

#### Páginas Implementadas
- ✅ Página de Login/Registro
- ✅ Dashboard do Cliente
- ✅ Dashboard do Comerciante
- ✅ Dashboard do Entregador

#### Funcionalidades em Desenvolvimento
- 🔄 Explorar comerciantes
- 🔄 Gerenciar produtos
- 🔄 Criar e acompanhar pedidos
- 🔄 Gerenciar entregas

## Modelos de Dados

### User (Usuário)
- id (string, chave primária)
- name (string)
- email (string, único)
- phone (string)
- password_hash (string)
- user_type (enum: customer, merchant, driver, admin)
- is_active (boolean)
- created_at (datetime)
- last_signed_in (datetime)

### Merchant (Comerciante)
- id (string, chave primária)
- user_id (string, chave estrangeira)
- business_name (string)
- description (text)
- category (string)
- phone (string)
- address (text)
- latitude (float)
- longitude (float)
- is_active (boolean)
- rating (float)
- created_at (datetime)
- updated_at (datetime)

### Product (Produto)
- id (string, chave primária)
- merchant_id (string, chave estrangeira)
- name (string)
- description (text)
- price (float)
- category (string)
- image_url (text)
- is_available (boolean)
- created_at (datetime)
- updated_at (datetime)

### Order (Pedido)
- id (string, chave primária)
- customer_id (string, chave estrangeira)
- merchant_id (string, chave estrangeira)
- driver_id (string, chave estrangeira, opcional)
- status (enum: pending, accepted, preparing, ready, on_the_way, delivered, cancelled)
- total_amount (float)
- delivery_fee (float)
- delivery_address (text)
- delivery_latitude (float)
- delivery_longitude (float)
- notes (text)
- created_at (datetime)
- updated_at (datetime)
- delivered_at (datetime, opcional)

### OrderItem (Item do Pedido)
- id (string, chave primária)
- order_id (string, chave estrangeira)
- product_id (string, chave estrangeira)
- quantity (integer)
- price (float)
- created_at (datetime)

### Driver (Entregador)
- id (string, chave primária)
- user_id (string, chave estrangeira)
- full_name (string)
- phone (string)
- vehicle (string)
- license_plate (string)
- is_active (boolean)
- is_available (boolean)
- rating (float)
- total_deliveries (integer)
- created_at (datetime)
- updated_at (datetime)

## Variáveis de Ambiente

### Backend

Criar um arquivo `.env` na pasta `backend/` com as seguintes variáveis:

```
DATABASE_URL=sqlite:///./intera.db
SECRET_KEY=sua-chave-secreta-aqui-mude-em-producao
APP_NAME=Intera
APP_VERSION=1.0.0
DEBUG=True
```

### Frontend

Criar um arquivo `.env` na pasta `frontend/` com as seguintes variáveis:

```
API_URL=http://localhost:8000
```

## Testando a API

### Usando cURL

#### Registrar um novo usuário
```bash
curl -X POST "http://localhost:8000/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "João Silva",
    "email": "joao@example.com",
    "password": "senha123",
    "user_type": "customer"
  }'
```

#### Fazer login
```bash
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joao@example.com",
    "password": "senha123"
  }'
```

#### Listar comerciantes
```bash
curl -X GET "http://localhost:8000/api/merchants/" \
  -H "Content-Type: application/json"
```

### Usando a Documentação Interativa (Swagger)

Acesse `http://localhost:8000/docs` no navegador para testar todos os endpoints de forma interativa.

## Próximos Passos

1. **Completar o Frontend Streamlit**
   - Implementar páginas de exploração de comerciantes
   - Criar fluxo de pedidos para clientes
   - Implementar gerenciamento de produtos para comerciantes
   - Adicionar acompanhamento de entregas em tempo real

2. **Melhorias no Backend**
   - Implementar validações mais robustas
   - Adicionar paginação em todas as listas
   - Implementar filtros avançados
   - Adicionar logs e monitoramento

3. **Autenticação e Segurança**
   - Implementar refresh tokens
   - Adicionar rate limiting
   - Implementar CORS adequadamente
   - Adicionar validação de email

4. **Banco de Dados**
   - Migrar para PostgreSQL em produção
   - Implementar índices de banco de dados
   - Adicionar backup automático

5. **Testes**
   - Criar testes unitários
   - Criar testes de integração
   - Implementar testes de carga

6. **Deploy**
   - Containerizar com Docker
   - Configurar CI/CD
   - Deploy em servidor de produção

## Suporte

Para dúvidas ou problemas, consulte a documentação da API em `http://localhost:8000/docs` ou o arquivo `planejamento_intera_app.md`.

## Licença

Este projeto é desenvolvido para fins educacionais e comerciais.

