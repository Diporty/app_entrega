# Intera - Aplicativo de Entregas

Plataforma de entregas para integrar comércios de cidades pequenas, permitindo que clientes façam pedidos, comerciantes gerenciem seus produtos e entregadores realizem as entregas.

## Estrutura do Projeto

```
intera_delivery_app/
├── backend/                 # API FastAPI
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py         # Aplicação principal
│   │   ├── models.py       # Modelos SQLAlchemy
│   │   ├── schemas.py      # Schemas Pydantic
│   │   ├── database.py     # Configuração do banco de dados
│   │   └── routers/        # Rotas da API
│   │       ├── __init__.py
│   │       ├── auth.py
│   │       ├── merchants.py
│   │       ├── products.py
│   │       ├── orders.py
│   │       └── drivers.py
│   ├── requirements.txt
│   └── .env.example
├── frontend/               # Interface Streamlit
│   ├── app.py
│   ├── pages/
│   │   ├── __init__.py
│   │   ├── home.py
│   │   ├── customer.py
│   │   ├── merchant.py
│   │   └── driver.py
│   ├── components/
│   │   ├── __init__.py
│   │   ├── header.py
│   │   └── sidebar.py
│   ├── utils/
│   │   ├── __init__.py
│   │   └── api_client.py
│   ├── requirements.txt
│   └── .streamlit/
│       └── config.toml
├── planejamento_intera_app.md
└── docker-compose.yml      # Para facilitar desenvolvimento local
```

## Tecnologias

- **Backend:** FastAPI, SQLAlchemy, Pydantic
- **Frontend:** Streamlit
- **Banco de Dados:** SQLite (desenvolvimento) / PostgreSQL (produção)
- **Autenticação:** JWT
- **API:** RESTful

## Instalação e Execução

### Backend

```bash
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend

```bash
cd frontend
pip install -r requirements.txt
streamlit run app.py
```

## Próximos Passos

1. Implementar modelos de banco de dados
2. Criar rotas da API
3. Desenvolver interface Streamlit
4. Integração de autenticação
5. Testes e deploy

