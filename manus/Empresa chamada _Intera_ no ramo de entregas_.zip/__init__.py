\"\"\"Pacote da aplicação Intera.\"\"\"\n
